import React from 'react';
import { render, screen } from '@testing-library/react';
import Home from './Home';
import { BrowserRouter } from 'react-router-dom';

it('renders welcome message', () => {
  render(<BrowserRouter><Home /></BrowserRouter>);
  expect(screen.getByText('First slide label')).toBeInTheDocument();
    const image = screen.getByImg("img"); 
    expect(image).toHaveAttribute('src', '1.jpg');
    expect(image).toHaveAttribute('alt', 'slide1');
});