import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loadUsers } from "../redux/action";
import axios from "axios";
import banner from "../imgs/banner.jpg";
import { useNavigate, useParams } from "react-router-dom";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const ApplyJobs = () => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => {
    navigate("/jobs");
  };
  //const [simpleTextDisplay, setSimpleTextDisplay] = useState(false);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(loadUsers());
  }, [dispatch]);
  const params = useParams();
  const { users } = useSelector((state) => state.users);
  
  const Disablerole = users[params.id].role;
  const [error, setError] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const navigate = useNavigate();
  const [values, setValues] = useState({
    JobId: params.id,
    Name: "",
    Email: "",
    Mobile: "",
    address: "",
    Experience: "",
  });
  const onMobileHandler = (e) => {
    setValues({ ...values, Mobile: e.target.value });
  };
  const onExpHandler = (e) => {
    setValues({ ...values, Experience: e.target.value });
  };
  useEffect(() => {
    dispatch(loadUsers());
  }, [dispatch]);
  const handleEditUser = (e) => {
    e.preventDefault();
    if (
      values.Name !== "" &&
      values.Email !== "" &&
      values.Mobile !== "" &&
      values.address !== "" &&
      values.Experience
    ) {
      setIsSuccess(!isSuccess);
      axios.post("http://localhost:3001/Applied", values).then((res) => {
        console.log(values);
        setShow(true);
      });
    } else {
      setIsSuccess(isSuccess);
      setError("*Enter all the fields");
    }

    setValues({ Name: "", Email: "", Mobile: "", address: "", Experience: "" });
    //setSimpleTextDisplay(true);
  };
  return (
    <div className="container">
      <div className="row">
        <img className="mb-3 px-0 imgres" src={banner} alt={banner} />
        <div className="col-12 col-sm-12 col-md-10 col-lg-8 col-xl-8 mx-auto">
        <p className="text-checking text-danger">
          { (/^[A-Za-z]+$/).test(values.Name) && values.Name !== ""
            ? ""
            : "*Name should not be empty and should not contain special characters"}
        </p>
        <p className="text-checking text-danger">
          {/^\w+([\\.-]?\w+)*@\w+([\\.-]?\w+)*(\.\w{2,3})+$/.test(
            values.Email
          ) && values.Email !== ""
            ? ""
            : "*Email should not be empty and should be valid"}
        </p>
        <p className="text-checking text-danger">
          {values.Mobile !== "" && values.Mobile.length === 10
            ? ""
            : "*Mobile Number should not be empty and should be 10 digits "}
        </p>
        <p className="text-checking text-danger">
          {values.Experience !== "" &&
          values.Experience.length > 10 &&
          values.Experience.length < 150
            ? ""
            : "*Experience should not be empty and should be more than 10 and less than 150 "}
        </p>

        <h4 className="text-danger mt-4">{error}</h4>
        <form onSubmit={handleEditUser}>
          <div className="mt-2">
            <label className="form-label">Job ID: </label>
            <input
              className="form-control"
              type="text" value={params.id} disabled
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Role: </label>
            <input
              className="form-control"
              type="text" value={Disablerole} disabled
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Name: </label>
            <input
              className="form-control"
              value={values.Name}
              type="text"
              placeholder="Name"
              onChange={(e) => setValues({ ...values, Name: e.target.value })}
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Email: </label>
            <input
              className="form-control"
              value={values.Email}
              type="email"
              placeholder="Email"
              onChange={(e) => setValues({ ...values, Email: e.target.value })}
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Mobile: </label>
            <input
              className="form-control"
              value={values.Mobile}
              type="text"
              placeholder="Mobile"
              onChange={onMobileHandler}
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Address: </label>
            <input
              className="form-control"
              value={values.address}
              type="text"
              placeholder="Address"
              onChange={(e) =>
                setValues({ ...values, address: e.target.value })
              }
            />
          </div>

          <div className="mt-3">
            <label className="form-label">Experience: </label>
            <textarea
              className="form-control"
              value={values.Experience}
              type="text"
              placeholder="Experience"
              onChange={onExpHandler}
            />
          </div>
          <div className="mt-3">
            <button variant="primary" onClick={ApplyJobs} type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </form>
        </div>
        {/* {simpleTextDisplay ? (
          <div>
            <h1 className="text-danger">Application Details</h1>
            <h3>Job Id: {params.id}</h3>
            <p>{users[params.id].company}</p>
            <p>{users[params.id].salary}</p>
            <p>{users[params.id].location}</p>
            <p>{users[params.id].role}</p>
          </div>
        ) : (
          ""
        )} */}
        <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title  className="text-success">Congratulation for applying <span className="text-danger">{Disablerole}</span> role successfully</Modal.Title>
        </Modal.Header>
        <Modal.Body>Click back button to go to jobs page</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary"  onClick={handleShow}>
            Back
          </Button>
        </Modal.Footer>
      </Modal>
      </div>
    </div>
  );
};

export default ApplyJobs;
