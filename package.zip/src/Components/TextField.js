import React from "react";

const TextField = ({ label, inputProps, onChange, value, type, required }) => {
  return (
    <div className="mt-3">
      <label htmlFor="exampleInputEmail1" className="form-label">
        {label}:
      </label>
      <input
        {...inputProps}
        onChange={onChange}
        value={value}
        type={type}
        className="form-control"
        required={required}
      />
    </div>
  );
};

export default TextField;
