import React from "react";

const TextField = ({ label, inputProps, onChange, value, type }) => {
  return (
     

<form >
<div className="my-3">
  <label htmlFor="exampleInputEmail1" className="form-label">{label}:</label>
  <input {...inputProps}
            onChange={onChange}
            value={value} type={type} className="form-control" />
  </div>
  </form>
  );
};

export default TextField;
