import React, { useState } from 'react';
import contact from '../imgs/contact.jpg'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Contact = () => {
  const [error, setError] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const navigate = useNavigate();
  const [values, setValues] = useState({
    Name: "",
    Email: "",
    Mobile: "",
    Message: ""
  });
const onMobileHandler = (e) => {
  setValues({ ...values, Mobile: e.target.value });
}
const onMsgHandler = (e) => {
  setValues({ ...values,Message : e.target.value })
}
  
  const handleEditUser = (e) => {
    e.preventDefault();
    if (
      values.Name !== "" &&
      values.Email !== "" &&
      values.Mobile !== "" &&
      values.Message
    ) {
      setIsSuccess(!isSuccess);
      axios.post("http://localhost:3001/contact_info", values).then((res) => {
      console.log(values);
      navigate('/Home')
    });
    } else {
      setIsSuccess(isSuccess);
      setError("*Enter all the fields");
   }
    
    setValues({ Name: "", Email: "", Mobile: "",address:"", Message: "" });
    //setSimpleTextDisplay(true);
    
  };
    return (
        <div className='container'>
            <div className='row'>
        <img className="px-0 mb-4 imgres" src={contact} alt={contact} />
            <div className='col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6'>
                <h3 className='text-danger text-center'>Get In Touch</h3>
                
                <p className="text-checking text-danger">
          { (/^[A-Za-z]+$/).test(values.Name) && values.Name !== ""
            ? ""
            : "*Name should not be empty and should not contain special characters"}
        </p>
       <p className="text-checking text-danger">{/^\w+([\\.-]?\w+)*@\w+([\\.-]?\w+)*(\.\w{2,3})+$/.test(values.Email) && values.Email !== "" ? "" : "*Email should not be empty and should be valid"}</p>
        <p className="text-checking text-danger">{values.Mobile !== "" && values.Mobile.length === 10 ? "": "*Mobile Number should not be empty and should be 10 digits " }</p>
        <p className="text-checking text-danger">{values.Message !== "" && values.Message.length > 10 && values.Message.length < 150 ? "": "*Message should not be empty and should be more than 10 and less than 150 " }</p>
        
        <form onSubmit={handleEditUser}>
          <div className="mt-3">
            <label className="form-label">Name: </label>
            <input className="form-control"
              value={values.Name}
              type="text"
              placeholder="Name"
              onChange={e => setValues({...values, Name: e.target.value})}
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Email: </label>
            <input className="form-control"
              value={values.Email}
              type="email"
              placeholder="Email"
              onChange={(e) => setValues({ ...values, Email: e.target.value })}
            />
          </div>
          <div className="mt-3">
            <label className="form-label">Mobile: </label>
            <input className="form-control"
              value={values.Mobile}
              type="text"
              placeholder="Mobile"
              onChange={onMobileHandler}
            />
          </div>
         
          <div className="mt-3">
            <label className="form-label">Message: </label>
            <input className="form-control"
              value={values.Message}
              type="text"
              placeholder="Message"
              onChange={onMsgHandler}
            />
          </div>
          <div className="mt-3">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        <p className="text-danger">{error}</p>
        </form>
            </div>
                <img className='col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6' src="https://aus-finance.com.au/wp-content/uploads/2020/06/shirota-yuri-5IZwgy5LJp8-unsplash.jpg" alt="contact" />
            
            </div>
            <div className='border text-center w-100 address p-4 my-4'>
              Plot No 129 to 132, 1 & 2nd Floor, Block 1, Dlf Building, Near Aphb Colony, Gachibowli, Hyderabad - 500032<br />040 44514444
            
            </div>
        </div>
    );
};

export default Contact;