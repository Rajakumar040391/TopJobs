import React, {useEffect} from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {loadUsers} from '../redux/action';
//import './jobs.css'

const Jobs = () => {
  let dispatch = useDispatch();
  const navigate = useNavigate()
  const {users} =useSelector(state => state.users);

  useEffect(() => {
    dispatch(loadUsers());
  },[dispatch])

  const applyJob = (id) => {
    //console.log(users[id].role);
    navigate(`/ApplyJobs/${id}`)
  }

    return (
        <div>
          {
            users.map(job => {
              return (
                <div key={job.id} onClick={() => applyJob(job.id)} className="container shadow p-3 mb-5 mt-3 rounded jobs">
                  <h3>{job.role}</h3>
                  <p>{job.company}</p>
                  <p><span>{job.exp} Yrs</span>&nbsp;&nbsp;&nbsp;<span>{job.salary}</span>&nbsp;&nbsp;&nbsp;<span>{job.location}</span></p>
                </div>
              )
            })  
          }  
        </div>
    );
};

export default Jobs;