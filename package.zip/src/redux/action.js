import axios from "axios";

const getUsers = users => ({
    type: 'GET_USERS',
    payload: users
});



export const loadUsers = () => {
    return function(dispatch){
        axios.get('http://localhost:3001/user').then(res => {
            dispatch(getUsers(res.data));
        })
        .catch(error => console.log(error));
    }
}

export const applyjobs = (info) => {
    console.log(info);
    return function(dispatch){
        console.log(info);
        axios.post('http://localhost:3001/Applied',info).then(res => {
           console.log()
        })
        .catch(error => console.log(error));
    }
}

