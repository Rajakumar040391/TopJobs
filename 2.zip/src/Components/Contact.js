import React, { useState } from 'react';
import TextField from './TextField';
import contact from '../imgs/contact.jpg'

const Contact = () => {
    const [values, setValues] = useState({
        Name: "",
        Email: "",
        Mobile: "",
        Experience: "",
      });
    return (
        <div className='container'>
            <img className='col-12' src={contact} alt="contact_us" />
            <div className='row mt-4'>
            <div className='col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6'>
                <h3 className='text-danger text-center'>Get In Touch</h3>
            <TextField
          label="Name"
          value={values.Name}
          type="text"
          onChange={(e) => setValues({ ...values, Name: e.target.value })}
          inputProps={{ placeholder: "Enter the name" }}
        />
        <TextField
          label="Email"
          type="email"
          value={values.Email}
          onChange={(e) => setValues({ ...values, Email: e.target.value })}
          inputProps={{ placeholder: "Enter the Email" }}
        />
        <TextField
          label="Mobile"
          type="text"
          value={values.Mobile}
          onChange={(e) => setValues({ ...values, Mobile: e.target.value })}
          inputProps={{ placeholder: "Enter the Mobile Number" }}
        />
        <TextField
          label="Experience"
          type="text"
          value={values.Experience}
          onChange={(e) => setValues({ ...values, Experience: e.target.value })}
          inputProps={{ placeholder: "Enter the Experience" }}
        />
        <div className='text-center mt-3'>
          <button
            type="submit"
            className="btn btn-danger"
          >
            Submit
          </button>
        </div>
            </div>
                <img className='col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6' src="https://aus-finance.com.au/wp-content/uploads/2020/06/shirota-yuri-5IZwgy5LJp8-unsplash.jpg" alt="contact" />
            
            </div>
        </div>
    );
};

export default Contact;