import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import TextField from "./TextField";
//import { applyjobs } from "../redux/action";
import { useDispatch, useSelector } from "react-redux";
import { loadUsers } from "../redux/action";
import axios from "axios";
import banner from '../imgs/banner.jpg'

const ApplyJobs = () => {
  const params = useParams();
  const [simpleTextDisplay, setSimpleTextDisplay] = useState(false);
  const [values, setValues] = useState({
    Name: "",
    Email: "",
    Mobile: "",
    Experience: "",
  });
  const { users } = useSelector((state) => state.users);
  let dispatch = useDispatch();

  useEffect(() => {
    dispatch(loadUsers());
  }, [dispatch]);
 
  const handleEditUser = () => {
    // applyjobs({
    //   id: params.id,
    //   Name: values.Name,
    //   Email: values.Email,
    //   Mobile: values.Mobile,
    //   Experience: values.Experience,
    // });
    setValues({Name: "", Email: "", Mobile: "", Experience: "" });
    setSimpleTextDisplay(true);
    axios.post('http://localhost:3001/Applied',values).then(res => {
           console.log(values);
        })
  };
  return (
    <div className="container">
      <div className="row">
        <img src={banner} alt={banner} />
        <TextField
          label="Name"
          value={values.Name}
          type="text"
          onChange={(e) => setValues({ ...values, Name: e.target.value })}
          inputProps={{ placeholder: "Enter the name" }}
        />
        <TextField
          label="Email"
          type="email"
          value={values.Email}
          onChange={(e) => setValues({ ...values, Email: e.target.value })}
          inputProps={{ placeholder: "Enter the Email" }}
        />
        <TextField
          label="Mobile"
          type="text"
          value={values.Mobile}
          onChange={(e) => setValues({ ...values, Mobile: e.target.value })}
          inputProps={{ placeholder: "Enter the Mobile Number" }}
        />
        <TextField
          label="Experience"
          type="text"
          value={values.Experience}
          onChange={(e) => setValues({ ...values, Experience: e.target.value })}
          inputProps={{ placeholder: "Enter the Experience" }}
        />
        <div className="mt-3">
          <button
            type="submit"
            className="btn btn-primary"
            onClick={handleEditUser}
          >
            Submit
          </button>
        </div>
        {simpleTextDisplay ? (
          <div>
            <h1 className="text-danger">Application Details</h1>
            <h3>Job Id: {params.id}</h3>
            <p>{users[params.id].company}</p>
            <p>{users[params.id].salary}</p>
            <p>{users[params.id].location}</p>
            <p>{users[params.id].role}</p>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default ApplyJobs;
