import React from "react";

const TextField = ({ label, inputProps, onChange, value, type }) => {
  return (
     

<form className="mt-3">
<div>
  <label htmlFor="exampleInputEmail1" className="form-label">{label}:</label>
  <input {...inputProps}
            onChange={onChange}
            value={value} type={type} className="form-control" />
  </div>
  </form>
  );
};

export default TextField;
