
const initialState = {
    users: [],
    user: {},
    loading: false
};

const usersReducers = (state = initialState,action) => {
switch(action.type){
    case "GET_USERS":
        //console.log(action.payload);
        return {
            ...state,
            users: action.payload,
            loading: false
        }
        case "APPLY_JOBS":
            console.log(action.payload);
            return {
                ...state,
                user: action.payload,
                loading: false
            }
    default:
        return state;
}
}
export default usersReducers;